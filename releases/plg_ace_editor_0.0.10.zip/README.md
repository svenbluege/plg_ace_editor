plg_ace_editor
==============

A Joomla Editor plugin which uses the ACE editor (http://ace.c9.io/)

![Screenshot](https://raw2.github.com/svenbluege/plg_ace_editor/master/preview.jpg)


## Install

Just pack all the files into a zip file and use the Joomla Extension Manager to install it. There is no need to add the releases folder. But you can grab a working package from this folder.
